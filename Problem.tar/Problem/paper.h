#define maxlen 20
typedef struct Paper{
	int score;
	char student_id[maxlen];
}Paper;

void QAQ_I_AM_SAD(int i, Paper *form);
void Nooooo(int i, Paper *form);
