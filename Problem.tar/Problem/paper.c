#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "paper.h"
void QAQ_I_AM_SAD(int i, Paper *form){
	scanf("%s", &form->student_id);
	return;	
}
void Nooooo(int i, Paper *form){
	scanf("%d", &form->score);
	return;
}
