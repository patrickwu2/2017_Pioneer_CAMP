#include <stdio.h>
#include <stdlib.h>
#include "paper.h"
int main(){
	FILE *fp;
	fp = fopen("JUDGE_GIRL_WILL_HELP_THEM", "w+");
	for(int i = 0; i < 50; i++){
		Paper form;
		QAQ_I_AM_SAD(i, &form);
		Nooooo(i, &form);
		if(form.score > 30)
			fprintf(fp,"%s %d\n", form.student_id, form.score);
	}
}
